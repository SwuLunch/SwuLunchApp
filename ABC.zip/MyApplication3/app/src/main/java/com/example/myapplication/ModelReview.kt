package com.example.myapplication


class ModelReview (
    var id : String,
    var name: String,
    var image: String,
    var contentt : String,
    var ratingstar : String,
    var addedTime:String
)