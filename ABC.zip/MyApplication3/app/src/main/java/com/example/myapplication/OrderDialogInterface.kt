package com.example.myapplication

interface OrderDialogInterface {

    fun onOrderBtnClick()

}