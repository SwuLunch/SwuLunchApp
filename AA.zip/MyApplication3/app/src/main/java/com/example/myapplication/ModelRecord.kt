package com.example.myapplication


class ModelRecord (
    var id: String,
    var name: String,
    var address: String,
    var time: String,
    var contentt : String,
    var addedTime:String,
    var updatedTime:String
)